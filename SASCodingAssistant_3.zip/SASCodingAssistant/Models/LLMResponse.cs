using System.Text.Json.Serialization;

namespace SASCodingAssistant.Models;

public class LLMResponse
{
    [JsonPropertyName("content")]
    public string Content { get; set; } = string.Empty;
    
    [JsonPropertyName("model")]
    public string Model { get; set; } = string.Empty;
    
    [JsonPropertyName("tokens_used")]
    public int TokensUsed { get; set; }
}
