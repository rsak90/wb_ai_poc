namespace SASCodingAssistant.Models;

public class AzureFoundrySettings
{
    public string Endpoint { get; set; } = string.Empty;
    public string ApiKey { get; set; } = string.Empty;
    public int TimeoutSeconds { get; set; } = 30;
    public string ModelName { get; set; } = string.Empty;
}
