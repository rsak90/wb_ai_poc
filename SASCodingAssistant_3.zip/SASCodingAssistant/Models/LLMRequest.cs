using System.Text.Json.Serialization;

namespace SASCodingAssistant.Models;

public class LLMRequest
{
    [JsonPropertyName("prompt")]
    public string Prompt { get; set; } = string.Empty;
    
    [JsonPropertyName("max_tokens")]
    public int MaxTokens { get; set; } = 1000;
    
    [JsonPropertyName("temperature")]
    public double Temperature { get; set; } = 0.7;
}
