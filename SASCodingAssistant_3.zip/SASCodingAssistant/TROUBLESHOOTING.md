# Troubleshooting Guide

## Azure Foundry API Issues

### Recent Fix Applied

The Azure Foundry service has been updated to use the correct Azure OpenAI API format:

**Changes Made:**
1. Updated request format to use `messages` array with `role` and `content`
2. Changed authentication to use `api-key` header only
3. Updated response parsing to handle Azure OpenAI response format
4. Added detailed logging for debugging

### Current Configuration

Your `appsettings.json` should have:

```json
{
  "AzureFoundry": {
    "Endpoint": "https://ajith9350-resource.cognitiveservices.azure.com/openai/deployments/gpt-4o-mini/chat/completions?api-version=2025-01-01-preview",
    "ApiKey": "YOUR_API_KEY",
    "TimeoutSeconds": 30,
    "ModelName": "gpt-4o-mini"
  }
}
```

### Testing the API

1. **Start the application:**
   ```bash
   cd SASCodingAssistant
   dotnet run
   ```

2. **Check the console logs** for:
   - "Sending request to Azure Foundry endpoint"
   - Request body details
   - Any error messages

3. **Test Error Analysis:**
   - Click the AI Assistant star button
   - Click "Analyze Error"
   - Check browser console (F12) for any errors
   - Check application console for detailed logs

4. **Test Q&A Mode:**
   - Switch to Q&A mode
   - Ask a simple question
   - Check for responses

### Common Issues and Solutions

#### Issue: "Unable to connect to AI service"

**Possible Causes:**
- Invalid API key
- Incorrect endpoint URL
- Network connectivity issues
- API quota exceeded

**Solutions:**
1. Verify your API key is correct in `appsettings.json`
2. Check the endpoint URL format
3. Test the endpoint directly using curl:
   ```bash
   curl -X POST "YOUR_ENDPOINT" \
     -H "api-key: YOUR_API_KEY" \
     -H "Content-Type: application/json" \
     -d '{
       "messages": [
         {"role": "system", "content": "You are a helpful assistant."},
         {"role": "user", "content": "Hello"}
       ],
       "max_tokens": 100
     }'
   ```

#### Issue: "Request timed out"

**Solutions:**
1. Increase timeout in `appsettings.json`:
   ```json
   "TimeoutSeconds": 60
   ```
2. Check your internet connection
3. Try again during off-peak hours

#### Issue: JSON parsing errors

**Possible Causes:**
- Azure API response format changed
- Model returning non-JSON content

**Solutions:**
1. Check application logs for raw response
2. The service now has fallback parsing logic
3. Response will be returned as plain text if JSON parsing fails

### Debugging Steps

1. **Enable detailed logging:**
   
   In `appsettings.json`, set:
   ```json
   {
     "Logging": {
       "LogLevel": {
         "Default": "Debug",
         "Microsoft.AspNetCore": "Information"
       }
     }
   }
   ```

2. **Check browser console:**
   - Open DevTools (F12)
   - Go to Console tab
   - Look for JavaScript errors
   - Check Network tab for API call details

3. **Check application logs:**
   - Look at the console where `dotnet run` is running
   - Check for error messages
   - Look for request/response details

4. **Test API endpoint directly:**
   
   Use Postman or curl to test:
   ```bash
   curl -X POST "http://localhost:5000/api/ai/error-analysis" \
     -H "Content-Type: application/json" \
     -d '{
       "code": "DATA test; RUN;",
       "errorOutput": "ERROR: Test error"
     }'
   ```

### Request Format

The service now sends requests in this format:

```json
{
  "messages": [
    {
      "role": "system",
      "content": "You are a helpful SAS programming assistant."
    },
    {
      "role": "user",
      "content": "Your prompt here"
    }
  ],
  "max_tokens": 1000,
  "temperature": 0.7,
  "model": "gpt-4o-mini"
}
```

### Response Format Expected

Azure OpenAI returns:

```json
{
  "choices": [
    {
      "message": {
        "role": "assistant",
        "content": "Response text here"
      }
    }
  ]
}
```

### Getting Help

If issues persist:

1. Check Azure Portal for API usage and errors
2. Verify your Azure OpenAI deployment is active
3. Check API version compatibility
4. Review Azure OpenAI service health status

### Logs to Check

When reporting issues, include:
- Application console output
- Browser console errors
- Network tab showing the failed request
- Response body from the API call
