# DevExpress Setup Instructions

## Prerequisites
1. DevExpress Universal Subscription or ASP.NET Core Subscription
2. DevExpress NuGet Feed configured

## Setup Steps

### 1. Configure DevExpress NuGet Feed
Add the DevExpress NuGet feed to your NuGet.config:

```xml
<?xml version="1.0" encoding="utf-8"?>
<configuration>
  <packageSources>
    <add key="DevExpress" value="https://nuget.devexpress.com/{YOUR-FEED-AUTHORIZATION-KEY}/api" />
  </packageSources>
</configuration>
```

### 2. Install DevExpress Packages
Uncomment the following line in `SASCodingAssistant.csproj`:
```xml
<PackageReference Include="DevExpress.AspNetCore" Version="24.2.3" />
```

Then run:
```bash
dotnet restore
```

### 3. Configure DevExpress in Program.cs
The application is already configured to use DevExpress services. Once packages are installed, the app will use DevExpress components.

### 4. Components Used
- **DevExpress.AspNetCore.HtmlEditor** - Code editor and output window
- **DevExpress.AspNetCore.Bootstrap** - Layout and responsive design
- **DevExpress.AspNetCore.Button** - Mode selection buttons
- **DevExpress.AspNetCore.LoadPanel** - Loading indicators

## Alternative: Use Without DevExpress
The application will work with standard HTML controls if DevExpress is not configured. The UI will be functional but without DevExpress styling and advanced features.
