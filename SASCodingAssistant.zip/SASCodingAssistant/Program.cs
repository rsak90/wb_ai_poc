using SASCodingAssistant.Models;
using SASCodingAssistant.Services;

var builder = WebApplication.CreateBuilder(args);

// Add services to the container.
builder.Services.AddControllersWithViews();

// Configure Azure Foundry settings
builder.Services.Configure<AzureFoundrySettings>(
    builder.Configuration.GetSection("AzureFoundry"));

// Register HttpClient factory
builder.Services.AddHttpClient();

// Register Azure Foundry service
builder.Services.AddScoped<IAzureFoundryService, AzureFoundryService>();

// Validate Azure Foundry configuration on startup
var azureFoundrySettings = builder.Configuration
    .GetSection("AzureFoundry")
    .Get<AzureFoundrySettings>();

if (azureFoundrySettings == null || 
    string.IsNullOrWhiteSpace(azureFoundrySettings.Endpoint) ||
    string.IsNullOrWhiteSpace(azureFoundrySettings.ApiKey))
{
    builder.Logging.AddConsole();
    var logger = LoggerFactory.Create(config => config.AddConsole())
        .CreateLogger("Startup");
    logger.LogError("Azure Foundry configuration is missing or invalid. Please configure the AzureFoundry section in appsettings.json");
}

// Configure DevExpress services (uncomment when DevExpress packages are installed)
// builder.Services.AddDevExpressControls();

var app = builder.Build();

// Configure the HTTP request pipeline.
if (!app.Environment.IsDevelopment())
{
    app.UseExceptionHandler("/Home/Error");
    // The default HSTS value is 30 days. You may want to change this for production scenarios, see https://aka.ms/aspnetcore-hsts.
    app.UseHsts();
}

app.UseHttpsRedirection();

// Configure DevExpress resources (uncomment when DevExpress packages are installed)
// app.UseDevExpressControls();

app.UseRouting();

app.UseAuthorization();

app.MapStaticAssets();

app.MapControllerRoute(
    name: "default",
    pattern: "{controller=Home}/{action=Index}/{id?}")
    .WithStaticAssets();


app.Run();
