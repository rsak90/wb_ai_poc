using System.Text.Json.Serialization;

namespace SASCodingAssistant.Models;

public class ErrorAnalysisResponse
{
    [JsonPropertyName("errorExplanation")]
    public string ErrorExplanation { get; set; } = string.Empty;
    
    [JsonPropertyName("rootCause")]
    public string RootCause { get; set; } = string.Empty;
    
    [JsonPropertyName("suggestedFix")]
    public string SuggestedFix { get; set; } = string.Empty;
    
    [JsonPropertyName("fixedCode")]
    public string FixedCode { get; set; } = string.Empty;
}
