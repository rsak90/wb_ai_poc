namespace SASCodingAssistant.Models;

public class QuestionRequest
{
    public string Question { get; set; } = string.Empty;
    public string? Context { get; set; }
}
