// AI Assistant JavaScript

// State management
let currentMode = 'errorAnalysis';
let conversationHistory = {
    errorAnalysis: [],
    qa: []
};
let sidebarVisible = false;

// DOM Elements
const aiAssistantToggle = document.getElementById('aiAssistantToggle');
const closeSidebar = document.getElementById('closeSidebar');
const aiSidebar = document.getElementById('aiSidebar');
const mainContent = document.getElementById('mainContent');
const errorAnalysisBtn = document.getElementById('errorAnalysisBtn');
const qaBtn = document.getElementById('qaBtn');
const errorAnalysisMode = document.getElementById('errorAnalysisMode');
const qaMode = document.getElementById('qaMode');
const analyzeBtn = document.getElementById('analyzeBtn');
const askBtn = document.getElementById('askBtn');
const loadingIndicator = document.getElementById('loadingIndicator');
const responseArea = document.getElementById('responseArea');
const codeEditor = document.getElementById('codeEditor');
const outputWindow = document.getElementById('outputWindow');
const questionInput = document.getElementById('questionInput');

// AI Assistant Toggle
aiAssistantToggle.addEventListener('click', () => {
    toggleSidebar();
});

closeSidebar.addEventListener('click', () => {
    toggleSidebar();
});

function toggleSidebar() {
    sidebarVisible = !sidebarVisible;
    
    if (sidebarVisible) {
        // Show sidebar
        aiSidebar.style.display = 'flex';
        aiSidebar.classList.remove('hide');
        aiSidebar.classList.add('show');
        mainContent.classList.add('sidebar-open');
        aiAssistantToggle.classList.add('active');
    } else {
        // Hide sidebar
        aiSidebar.classList.remove('show');
        aiSidebar.classList.add('hide');
        mainContent.classList.remove('sidebar-open');
        aiAssistantToggle.classList.remove('active');
        
        // Wait for animation to complete before hiding
        setTimeout(() => {
            if (!sidebarVisible) {
                aiSidebar.style.display = 'none';
            }
        }, 300);
    }
}

// Mode Switching
errorAnalysisBtn.addEventListener('click', () => {
    switchMode('errorAnalysis');
});

qaBtn.addEventListener('click', () => {
    switchMode('qa');
});

function switchMode(mode) {
    currentMode = mode;
    
    if (mode === 'errorAnalysis') {
        // Update button states
        errorAnalysisBtn.classList.add('active');
        errorAnalysisBtn.classList.remove('btn-outline-primary');
        errorAnalysisBtn.classList.add('btn-primary');
        
        qaBtn.classList.remove('active');
        qaBtn.classList.remove('btn-primary');
        qaBtn.classList.add('btn-outline-primary');
        
        // Show/hide mode content
        errorAnalysisMode.classList.remove('d-none');
        qaMode.classList.add('d-none');
    } else {
        // Update button states
        qaBtn.classList.add('active');
        qaBtn.classList.remove('btn-outline-primary');
        qaBtn.classList.add('btn-primary');
        
        errorAnalysisBtn.classList.remove('active');
        errorAnalysisBtn.classList.remove('btn-primary');
        errorAnalysisBtn.classList.add('btn-outline-primary');
        
        // Show/hide mode content
        qaMode.classList.remove('d-none');
        errorAnalysisMode.classList.add('d-none');
    }
    
    // Restore conversation history for the selected mode
    displayConversationHistory(mode);
}

function displayConversationHistory(mode) {
    const history = conversationHistory[mode];
    if (history.length === 0) {
        responseArea.innerHTML = `
            <div class="empty-state">
                <i class="bi bi-chat-dots" style="font-size: 3rem; opacity: 0.3;"></i>
                <p class="text-muted mt-3">AI responses will appear here...</p>
            </div>
        `;
    } else {
        responseArea.innerHTML = history.join('<hr style="margin: 1.5rem 0; border-color: var(--border-color);">');
    }
}

// Error Analysis
analyzeBtn.addEventListener('click', async () => {
    const code = codeEditor.value.trim();
    const errorOutput = outputWindow.value.trim();
    
    if (!code && !errorOutput) {
        showError('Please provide either code or error output to analyze.');
        return;
    }
    
    showLoading(true);
    
    try {
        const response = await fetch('/api/ai/error-analysis', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                code: code,
                errorOutput: errorOutput
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to analyze error');
        }
        
        const data = await response.json();
        displayErrorAnalysis(data);
        
        // Save to history
        conversationHistory.errorAnalysis.push(responseArea.innerHTML);
        
    } catch (error) {
        showError(`Error: ${error.message}`);
    } finally {
        showLoading(false);
    }
});

function displayErrorAnalysis(data) {
    const html = `
        <div class="error-section">
            <div class="section-title">
                <i class="bi bi-exclamation-triangle-fill text-danger"></i> Error Explanation
            </div>
            <p>${escapeHtml(data.errorExplanation)}</p>
        </div>
        
        <div class="error-section">
            <div class="section-title">
                <i class="bi bi-search text-warning"></i> Root Cause
            </div>
            <p>${escapeHtml(data.rootCause)}</p>
        </div>
        
        <div class="fix-section">
            <div class="section-title">
                <i class="bi bi-wrench text-success"></i> Suggested Fix
            </div>
            <p>${escapeHtml(data.suggestedFix)}</p>
        </div>
        
        ${data.fixedCode ? `
        <div class="fix-section">
            <div class="section-title">
                <i class="bi bi-code-square text-success"></i> Fixed Code
            </div>
            <pre><code>${escapeHtml(data.fixedCode)}</code></pre>
        </div>
        ` : ''}
    `;
    
    responseArea.innerHTML = html;
}

// Q&A Mode
askBtn.addEventListener('click', async () => {
    const question = questionInput.value.trim();
    
    if (!question) {
        showError('Please enter a question.');
        return;
    }
    
    showLoading(true);
    
    try {
        // Get conversation context
        const context = conversationHistory.qa.length > 0 
            ? conversationHistory.qa.slice(-3).join('\n\n') 
            : null;
        
        const response = await fetch('/api/ai/question-answer', {
            method: 'POST',
            headers: {
                'Content-Type': 'application/json'
            },
            body: JSON.stringify({
                question: question,
                context: context
            })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to get answer');
        }
        
        const data = await response.json();
        displayQAResponse(question, data.answer);
        
        // Save to history
        const historyEntry = `<strong>Q:</strong> ${escapeHtml(question)}<br><strong>A:</strong> ${escapeHtml(data.answer)}`;
        conversationHistory.qa.push(historyEntry);
        
        // Clear question input
        questionInput.value = '';
        
    } catch (error) {
        showError(`Error: ${error.message}`);
    } finally {
        showLoading(false);
    }
});

function displayQAResponse(question, answer) {
    const html = `
        <div class="mb-3">
            <div class="section-title">
                <i class="bi bi-question-circle text-primary me-2"></i> Question
            </div>
            <p>${escapeHtml(question)}</p>
        </div>
        
        <div class="mb-3">
            <div class="section-title">
                <i class="bi bi-chat-left-text text-success me-2"></i> Answer
            </div>
            <p>${escapeHtml(answer)}</p>
        </div>
    `;
    
    // Append to existing conversation
    if (responseArea.innerHTML.includes('empty-state') || responseArea.innerHTML.includes('AI responses will appear here')) {
        responseArea.innerHTML = html;
    } else {
        responseArea.innerHTML += '<hr style="margin: 1.5rem 0; border-color: var(--border-color);">' + html;
    }
}

// Utility Functions
function showLoading(show) {
    if (show) {
        loadingIndicator.classList.remove('d-none');
        analyzeBtn.disabled = true;
        askBtn.disabled = true;
    } else {
        loadingIndicator.classList.add('d-none');
        analyzeBtn.disabled = false;
        askBtn.disabled = false;
    }
}

function showError(message) {
    const html = `
        <div class="alert-custom alert-error">
            <i class="bi bi-exclamation-circle"></i> ${escapeHtml(message)}
        </div>
    `;
    responseArea.innerHTML = html;
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Clear buttons functionality
document.getElementById('clearCode')?.addEventListener('click', () => {
    if (confirm('Clear all code?')) {
        codeEditor.value = '';
        codeEditor.focus();
    }
});

document.getElementById('clearOutput')?.addEventListener('click', () => {
    if (confirm('Clear output log?')) {
        outputWindow.value = '';
    }
});

document.getElementById('clearResponse')?.addEventListener('click', () => {
    if (confirm('Clear AI response?')) {
        responseArea.innerHTML = `
            <div class="empty-state">
                <i class="bi bi-chat-dots" style="font-size: 3rem; opacity: 0.3;"></i>
                <p class="text-muted mt-3">AI responses will appear here...</p>
            </div>
        `;
        conversationHistory[currentMode] = [];
    }
});

// Keyboard shortcuts
document.addEventListener('keydown', (e) => {
    // Ctrl/Cmd + Enter to analyze/ask
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter') {
        if (sidebarVisible) {
            if (currentMode === 'errorAnalysis') {
                analyzeBtn.click();
            } else {
                askBtn.click();
            }
        }
    }
    
    // Escape to close sidebar
    if (e.key === 'Escape' && sidebarVisible) {
        toggleSidebar();
    }
});

// Initialize
switchMode('errorAnalysis');
