using Microsoft.AspNetCore.Mvc;
using SASCodingAssistant.Models;
using SASCodingAssistant.Services;

namespace SASCodingAssistant.Controllers.AI;

[ApiController]
[Route("api/ai/question-answer")]
public class QuestionAnswerController : ControllerBase
{
    private readonly IAzureFoundryService _azureFoundryService;
    private readonly ILogger<QuestionAnswerController> _logger;

    public QuestionAnswerController(
        IAzureFoundryService azureFoundryService,
        ILogger<QuestionAnswerController> logger)
    {
        _azureFoundryService = azureFoundryService;
        _logger = logger;
    }

    [HttpPost]
    public async Task<IActionResult> AskQuestion([FromBody] QuestionRequest request)
    {
        try
        {
            // Validate request
            if (string.IsNullOrWhiteSpace(request.Question))
            {
                return BadRequest(new ErrorResponse
                {
                    Error = "ValidationError",
                    Message = "Question cannot be empty",
                    StatusCode = 400
                });
            }

            _logger.LogInformation("Processing Q&A request");

            var answer = await _azureFoundryService.AnswerQuestionAsync(
                request.Question, 
                request.Context);

            var response = new QuestionAnswerResponse
            {
                Answer = answer,
                ConversationId = Guid.NewGuid().ToString()
            };

            return Ok(response);
        }
        catch (TimeoutException ex)
        {
            _logger.LogWarning(ex, "Request timed out");
            return StatusCode(408, new ErrorResponse
            {
                Error = "Timeout",
                Message = "The request timed out. Please try again.",
                Details = ex.Message,
                StatusCode = 408
            });
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "Error communicating with Azure Foundry");
            return StatusCode(502, new ErrorResponse
            {
                Error = "ServiceUnavailable",
                Message = "Unable to connect to AI service. Please try again later.",
                Details = ex.Message,
                StatusCode = 502
            });
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error in Q&A");
            return StatusCode(500, new ErrorResponse
            {
                Error = "InternalError",
                Message = "An unexpected error occurred",
                Details = ex.Message,
                StatusCode = 500
            });
        }
    }
}
