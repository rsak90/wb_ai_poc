// SAS Coding Assistant - DevExpress Implementation

// State management
let currentMode = 'errorAnalysis';
let conversationHistory = { errorAnalysis: [], qa: [] };
let sidebarVisible = false;

// Initialize DevExpress Components
$(document).ready(function() {
    initializeComponents();
});

function initializeComponents() {
    if (typeof DevExpress === 'undefined') {
        console.warn('DevExpress not found');
        return;
    }

    // Header Toolbar
    $('#headerToolbar').dxToolbar({
        items: [
            { 
                location: 'before', 
                text: 'SAS Coding Assistant',
                template: function() {
                    return $('<h4 style="margin:0; color:white;">SAS Coding Assistant</h4>');
                }
            },
            {
                location: 'after',
                widget: 'dxButton',
                options: {
                    text: 'AI Assistant',
                    icon: 'sparkles',
                    type: 'default',
                    stylingMode: 'contained',
                    onClick: () => toggleSidebar()
                }
            }
        ]
    });

    // Code Editor
    $('#codeEditor').dxTextArea({
        value: `/* Sample SAS Code */
DATA work.sample;
    INPUT name $ age;
    DATALINES;
John 25
Jane 30
Bob 35
;
RUN;

PROC PRINT DATA=work.sample;
RUN;`,
        placeholder: 'Enter your SAS code here...',
        height: '100%'
    });

    // Output Window
    $('#outputWindow').dxTextArea({
        value: `ERROR: Variable NAME not found.
ERROR: The variable AGE in the DROP, KEEP, or RENAME list has never been referenced.
NOTE: The SAS System stopped processing this step because of errors.
WARNING: The data set WORK.SAMPLE may be incomplete.`,
        readOnly: true,
        height: '100%'
    });

    // Close Sidebar Button
    $('#closeSidebar').dxButton({
        icon: 'close',
        type: 'normal',
        stylingMode: 'text',
        onClick: () => toggleSidebar()
    });

    // Mode Selector
    $('#modeSelector').dxButtonGroup({
        items: [
            { text: 'Error Analysis', icon: 'bug', value: 'errorAnalysis' },
            { text: 'Q&A Mode', icon: 'comment', value: 'qa' }
        ],
        selectedItemKeys: ['errorAnalysis'],
        keyExpr: 'value',
        onSelectionChanged: function(e) {
            if (e.addedItems.length > 0) {
                switchMode(e.addedItems[0].value);
            }
        }
    });

    // Question Input
    $('#questionInput').dxTextArea({
        placeholder: 'e.g., How do I merge two datasets in SAS?',
        height: 80
    });

    // Action Buttons
    $('#analyzeBtn').dxButton({
        text: 'Analyze Error',
        icon: 'lightning',
        type: 'success',
        width: '100%',
        onClick: () => analyzeError()
    });

    $('#askBtn').dxButton({
        text: 'Ask Question',
        icon: 'send',
        type: 'success',
        width: '100%',
        onClick: () => askQuestion()
    });

    // Loading Spinner
    $('#loadingSpinner').dxLoadIndicator({
        visible: false
    });

    // Initialize mode
    switchMode('errorAnalysis');
}

function toggleSidebar() {
    const $sidebar = $('#aiSidebar');
    const $mainContent = $('#mainContent');
    
    sidebarVisible = !sidebarVisible;
    
    if (sidebarVisible) {
        $sidebar.show().addClass('show').removeClass('hide');
        $mainContent.addClass('sidebar-open');
    } else {
        $sidebar.addClass('hide').removeClass('show');
        $mainContent.removeClass('sidebar-open');
        setTimeout(() => {
            if (!sidebarVisible) $sidebar.hide();
        }, 300);
    }
}

function switchMode(mode) {
    currentMode = mode;
    
    const $errorMode = $('#errorAnalysisMode');
    const $qaMode = $('#qaMode');
    
    if (mode === 'errorAnalysis') {
        $errorMode.show();
        $qaMode.hide();
    } else {
        $qaMode.show();
        $errorMode.hide();
    }
    
    displayConversationHistory(mode);
}

function displayConversationHistory(mode) {
    const $responseArea = $('#responseArea');
    const history = conversationHistory[mode];
    
    if (history.length === 0) {
        showEmptyState();
    } else {
        $responseArea.html(history.join('<hr style="margin: 16px 0;">'));
    }
}

function showEmptyState() {
    $('#responseArea').html(`
        <div class="empty-state">
            <i class="dx-icon dx-icon-comment"></i>
            <p>AI responses will appear here...</p>
        </div>
    `);
}

async function analyzeError() {
    const codeValue = $('#codeEditor').dxTextArea('instance').option('value') || '';
    const outputValue = $('#outputWindow').dxTextArea('instance').option('value') || '';
    
    if (!codeValue && !outputValue) {
        showError('Please provide either code or error output to analyze.');
        return;
    }
    
    showLoading(true);
    
    try {
        const response = await fetch('/api/ai/error-analysis', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ code: codeValue, errorOutput: outputValue })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to analyze error');
        }
        
        const data = await response.json();
        displayErrorAnalysis(data);
        
        conversationHistory.errorAnalysis.push($('#responseArea').html());
        
    } catch (error) {
        showError(`Error: ${error.message}`);
    } finally {
        showLoading(false);
    }
}

async function askQuestion() {
    const question = $('#questionInput').dxTextArea('instance').option('value') || '';
    
    if (!question) {
        showError('Please enter a question.');
        return;
    }
    
    showLoading(true);
    
    try {
        const context = conversationHistory.qa.length > 0 
            ? conversationHistory.qa.slice(-3).join('\n\n') 
            : null;
        
        const response = await fetch('/api/ai/question-answer', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ question, context })
        });
        
        if (!response.ok) {
            const errorData = await response.json();
            throw new Error(errorData.message || 'Failed to get answer');
        }
        
        const data = await response.json();
        displayQAResponse(question, data.answer);
        
        const historyEntry = `<strong>Q:</strong> ${escapeHtml(question)}<br><strong>A:</strong> ${escapeHtml(data.answer)}`;
        conversationHistory.qa.push(historyEntry);
        
        $('#questionInput').dxTextArea('instance').option('value', '');
        
    } catch (error) {
        showError(`Error: ${error.message}`);
    } finally {
        showLoading(false);
    }
}

function displayErrorAnalysis(data) {
    const html = `
        <div class="response-section error-section">
            <div class="section-title">
                <i class="dx-icon dx-icon-warning"></i> Error Explanation
            </div>
            <p>${escapeHtml(data.errorExplanation)}</p>
        </div>
        
        <div class="response-section error-section">
            <div class="section-title">
                <i class="dx-icon dx-icon-search"></i> Root Cause
            </div>
            <p>${escapeHtml(data.rootCause)}</p>
        </div>
        
        <div class="response-section fix-section">
            <div class="section-title">
                <i class="dx-icon dx-icon-check"></i> Suggested Fix
            </div>
            <p>${escapeHtml(data.suggestedFix)}</p>
        </div>
        
        ${data.fixedCode ? `
        <div class="response-section fix-section">
            <div class="section-title">
                <i class="dx-icon dx-icon-code"></i> Fixed Code
            </div>
            <pre class="code-block">${escapeHtml(data.fixedCode)}</pre>
        </div>
        ` : ''}
    `;
    
    $('#responseArea').html(html);
}

function displayQAResponse(question, answer) {
    const html = `
        <div style="margin-bottom: 16px;">
            <div class="section-title">
                <i class="dx-icon dx-icon-help"></i> Question
            </div>
            <p>${escapeHtml(question)}</p>
        </div>
        
        <div style="margin-bottom: 16px;">
            <div class="section-title">
                <i class="dx-icon dx-icon-comment"></i> Answer
            </div>
            <p>${escapeHtml(answer)}</p>
        </div>
    `;
    
    const $responseArea = $('#responseArea');
    if ($responseArea.find('.empty-state').length > 0) {
        $responseArea.html(html);
    } else {
        $responseArea.append('<hr style="margin: 16px 0;">' + html);
    }
}

function showLoading(show) {
    const $loadingIndicator = $('#loadingIndicator');
    
    if (show) {
        $loadingIndicator.show();
        $('#loadingSpinner').dxLoadIndicator('instance').option('visible', true);
        $('#analyzeBtn').dxButton('instance').option('disabled', true);
        $('#askBtn').dxButton('instance').option('disabled', true);
    } else {
        $loadingIndicator.hide();
        $('#loadingSpinner').dxLoadIndicator('instance').option('visible', false);
        $('#analyzeBtn').dxButton('instance').option('disabled', false);
        $('#askBtn').dxButton('instance').option('disabled', false);
    }
}

function showError(message) {
    $('#responseArea').html(`
        <div style="background: #f8d7da; border: 1px solid #f5c6cb; color: #721c24; padding: 12px; border-radius: 4px; margin-bottom: 16px;">
            <i class="dx-icon dx-icon-warning"></i> ${escapeHtml(message)}
        </div>
    `);
}

function escapeHtml(text) {
    const div = document.createElement('div');
    div.textContent = text;
    return div.innerHTML;
}

// Keyboard shortcuts
$(document).keydown(function(e) {
    if ((e.ctrlKey || e.metaKey) && e.key === 'Enter' && sidebarVisible) {
        if (currentMode === 'errorAnalysis') {
            analyzeError();
        } else {
            askQuestion();
        }
    }
    
    if (e.key === 'Escape' && sidebarVisible) {
        toggleSidebar();
    }
});
