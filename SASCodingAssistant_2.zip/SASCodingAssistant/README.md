# SAS Coding Assistant

A .NET Core 9 MVC web application that provides AI-powered assistance for SAS code development using Azure Foundry's LLM capabilities.

## Features

- **Code Editor**: Mock SAS code editor for input
- **Output Window**: Display area for execution results and error messages
- **AI Assistant Sidebar**: Two operational modes:
  - **Error Analysis Mode**: Analyzes code errors and provides fix suggestions
  - **Q&A Mode**: Answers natural language questions about SAS programming
- **Conversation History**: Maintains separate history for each mode
- **Responsive Design**: Works on desktop and mobile devices

## Prerequisites

- .NET 9.0 SDK
- Azure Foundry LLM endpoint and API key
- (Optional) DevExpress ASP.NET Core license for enhanced UI components

## Setup Instructions

### 1. Configure Azure Foundry

Edit `appsettings.json` and update the Azure Foundry configuration:

```json
{
  "AzureFoundry": {
    "Endpoint": "https://your-azure-foundry-endpoint.com/api",
    "ApiKey": "your-api-key-here",
    "TimeoutSeconds": 30,
    "ModelName": "your-model-name"
  }
}
```

**Important**: For production, use User Secrets or environment variables instead of storing the API key in appsettings.json:

```bash
dotnet user-secrets init
dotnet user-secrets set "AzureFoundry:ApiKey" "your-api-key-here"
dotnet user-secrets set "AzureFoundry:Endpoint" "https://your-endpoint.com/api"
```

### 2. (Optional) Configure DevExpress

If you have a DevExpress license, follow the instructions in `DEVEXPRESS_SETUP.md` to enable DevExpress components.

### 3. Build and Run

```bash
dotnet restore
dotnet build
dotnet run
```

The application will be available at:
- HTTPS: https://localhost:5001
- HTTP: http://localhost:5000

## Project Structure

```
SASCodingAssistant/
├── Controllers/
│   ├── AI/                          # WebAPI controllers
│   │   ├── ErrorAnalysisController.cs
│   │   └── QuestionAnswerController.cs
│   └── HomeController.cs            # MVC controller
├── Models/                          # Data models
│   ├── AzureFoundrySettings.cs
│   ├── ErrorAnalysisRequest.cs
│   ├── ErrorAnalysisResponse.cs
│   ├── QuestionRequest.cs
│   ├── QuestionAnswerResponse.cs
│   ├── LLMRequest.cs
│   ├── LLMResponse.cs
│   └── ErrorResponse.cs
├── Services/                        # Business logic
│   ├── IAzureFoundryService.cs
│   └── AzureFoundryService.cs
├── Views/
│   ├── Home/
│   │   └── Index.cshtml            # Main application page
│   └── Shared/
│       └── _Layout.cshtml
├── wwwroot/
│   ├── css/
│   │   └── ai-assistant.css        # Custom styles
│   └── js/
│       └── ai-assistant.js         # Frontend logic
└── Program.cs                       # Application startup
```

## API Endpoints

### Error Analysis
- **POST** `/api/ai/error-analysis`
- Request body:
  ```json
  {
    "code": "SAS code here",
    "errorOutput": "Error message here"
  }
  ```
- Response:
  ```json
  {
    "errorExplanation": "...",
    "rootCause": "...",
    "suggestedFix": "...",
    "fixedCode": "..."
  }
  ```

### Question & Answer
- **POST** `/api/ai/question-answer`
- Request body:
  ```json
  {
    "question": "Your question here",
    "context": "Optional conversation context"
  }
  ```
- Response:
  ```json
  {
    "answer": "...",
    "conversationId": "..."
  }
  ```

## Usage

### Error Analysis Mode

1. Enter or paste SAS code in the code editor
2. Enter error messages in the output window
3. Click "Analyze Error" button
4. View the AI-generated analysis, root cause, and suggested fix

### Q&A Mode

1. Click the "Q&A Mode" button
2. Type your question in the input field
3. Click "Ask Question"
4. View the AI-generated answer
5. Ask follow-up questions (context is maintained)

## Architecture

The application follows a clean architecture pattern:

- **Presentation Layer**: MVC views and Razor pages
- **API Layer**: RESTful WebAPI controllers in Controllers/AI folder
- **Service Layer**: Business logic for Azure Foundry communication
- **Models**: Data transfer objects and configuration models

## Error Handling

The application includes comprehensive error handling:

- Configuration validation on startup
- HTTP error handling with appropriate status codes
- Timeout handling for LLM requests
- User-friendly error messages in the UI
- Detailed logging for debugging

## Development

### Adding New Features

1. Add models in `Models/` folder
2. Implement service logic in `Services/` folder
3. Create API endpoints in `Controllers/AI/` folder
4. Update frontend in `wwwroot/js/ai-assistant.js`
5. Add styles in `wwwroot/css/ai-assistant.css`

### Testing

The application is designed for minimal MVP. For comprehensive testing:

- Add unit tests for services and controllers
- Add integration tests for API endpoints
- Add property-based tests for core logic

## Troubleshooting

### Azure Foundry Connection Issues

- Verify the endpoint URL is correct
- Check that the API key is valid
- Ensure network connectivity to Azure Foundry
- Check application logs for detailed error messages

### Build Issues

- Ensure .NET 9.0 SDK is installed: `dotnet --version`
- Clear build artifacts: `dotnet clean`
- Restore packages: `dotnet restore`

## License

This project is for demonstration purposes.

## Support

For issues or questions, please refer to the project documentation or contact the development team.
