namespace SASCodingAssistant.Models;

public class ErrorAnalysisRequest
{
    public string Code { get; set; } = string.Empty;
    public string ErrorOutput { get; set; } = string.Empty;
}
