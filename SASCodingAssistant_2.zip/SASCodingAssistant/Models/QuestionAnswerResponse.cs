namespace SASCodingAssistant.Models;

public class QuestionAnswerResponse
{
    public string Answer { get; set; } = string.Empty;
    public string ConversationId { get; set; } = string.Empty;
}
