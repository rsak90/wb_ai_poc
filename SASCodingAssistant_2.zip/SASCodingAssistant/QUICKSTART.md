# Quick Start Guide

Get the SAS Coding Assistant up and running in 5 minutes!

## Step 1: Configure Azure Foundry (Required)

You need an Azure Foundry LLM endpoint to use the AI features.

### Option A: Using appsettings.json (Development Only)

Edit `appsettings.json`:

```json
{
  "AzureFoundry": {
    "Endpoint": "YOUR_AZURE_FOUNDRY_ENDPOINT_HERE",
    "ApiKey": "YOUR_API_KEY_HERE",
    "TimeoutSeconds": 30,
    "ModelName": "YOUR_MODEL_NAME"
  }
}
```

### Option B: Using User Secrets (Recommended)

```bash
cd SASCodingAssistant
dotnet user-secrets init
dotnet user-secrets set "AzureFoundry:Endpoint" "YOUR_ENDPOINT"
dotnet user-secrets set "AzureFoundry:ApiKey" "YOUR_API_KEY"
dotnet user-secrets set "AzureFoundry:ModelName" "YOUR_MODEL"
```

## Step 2: Run the Application

```bash
cd SASCodingAssistant
dotnet run
```

The application will start and display URLs:
```
Now listening on: https://localhost:5001
Now listening on: http://localhost:5000
```

## Step 3: Open in Browser

Navigate to: **https://localhost:5001**

## Step 4: Try It Out!

### Test Error Analysis Mode

1. The code editor already has sample SAS code
2. The output window shows sample errors
3. Click **"Analyze Error"** button
4. Wait for the AI to analyze and provide suggestions

### Test Q&A Mode

1. Click the **"Q&A Mode"** button
2. Type a question like: "How do I merge two datasets in SAS?"
3. Click **"Ask Question"**
4. View the AI-generated answer

## Troubleshooting

### "Azure Foundry configuration is missing"

- Make sure you've configured the endpoint and API key
- Check the console logs for specific errors
- Verify your API key is valid

### Application won't start

```bash
# Check .NET version
dotnet --version  # Should be 9.0.x

# Clean and rebuild
dotnet clean
dotnet restore
dotnet build
```

### Port already in use

Edit `Properties/launchSettings.json` to change the port numbers.

## Next Steps

- Read the full [README.md](README.md) for detailed documentation
- Customize the UI in `Views/Home/Index.cshtml`
- Modify AI prompts in `Services/AzureFoundryService.cs`
- Add DevExpress components (see `DEVEXPRESS_SETUP.md`)

## Need Help?

Check the application logs in the console for detailed error messages.
