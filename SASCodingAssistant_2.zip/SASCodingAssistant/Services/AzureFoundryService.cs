using System.Text;
using System.Text.Json;
using Microsoft.Extensions.Options;
using SASCodingAssistant.Models;

namespace SASCodingAssistant.Services;

public class AzureFoundryService : IAzureFoundryService
{
    private readonly HttpClient _httpClient;
    private readonly AzureFoundrySettings _settings;
    private readonly ILogger<AzureFoundryService> _logger;

    public AzureFoundryService(
        IHttpClientFactory httpClientFactory,
        IOptions<AzureFoundrySettings> settings,
        ILogger<AzureFoundryService> logger)
    {
        _httpClient = httpClientFactory.CreateClient();
        _settings = settings.Value;
        _logger = logger;

        // Configure timeout
        _httpClient.Timeout = TimeSpan.FromSeconds(_settings.TimeoutSeconds);
    }

    public async Task<string> SendPromptAsync(string prompt, CancellationToken cancellationToken = default)
    {
        try
        {
            // Azure OpenAI / Foundry format
            var requestBody = new
            {
                messages = new[]
                {
                    new
                    {
                        role = "system",
                        content = "You are a helpful SAS programming assistant."
                    },
                    new
                    {
                        role = "user",
                        content = prompt
                    }
                },
                max_tokens = 1000,
                temperature = 0.7,
                model = _settings.ModelName
            };

            var jsonRequest = JsonSerializer.Serialize(requestBody, new JsonSerializerOptions 
            { 
                WriteIndented = true 
            });
            
            _logger.LogInformation("Request body: {RequestBody}", jsonRequest);

            var httpRequest = new HttpRequestMessage(HttpMethod.Post, _settings.Endpoint)
            {
                Content = new StringContent(
                    jsonRequest,
                    Encoding.UTF8,
                    "application/json")
            };

            // Add authentication header (Azure uses api-key header)
            httpRequest.Headers.Add("api-key", _settings.ApiKey);

            _logger.LogInformation("Sending request to Azure Foundry endpoint: {Endpoint}", _settings.Endpoint);

            var response = await _httpClient.SendAsync(httpRequest, cancellationToken);

            if (!response.IsSuccessStatusCode)
            {
                var errorContent = await response.Content.ReadAsStringAsync(cancellationToken);
                _logger.LogError("Azure Foundry API error: {StatusCode} - {Error}", 
                    response.StatusCode, errorContent);
                throw new HttpRequestException($"Azure Foundry API returned {response.StatusCode}: {errorContent}");
            }

            var responseContent = await response.Content.ReadAsStringAsync(cancellationToken);
            _logger.LogInformation("Received response from Azure Foundry");

            // Parse Azure OpenAI response format
            using var doc = JsonDocument.Parse(responseContent);
            var root = doc.RootElement;
            
            // Try to get content from choices array
            if (root.TryGetProperty("choices", out var choices) && choices.GetArrayLength() > 0)
            {
                var firstChoice = choices[0];
                if (firstChoice.TryGetProperty("message", out var message))
                {
                    if (message.TryGetProperty("content", out var content))
                    {
                        return content.GetString() ?? string.Empty;
                    }
                }
            }

            // Fallback: try direct content property
            if (root.TryGetProperty("content", out var directContent))
            {
                return directContent.GetString() ?? string.Empty;
            }

            _logger.LogWarning("Unable to parse response format. Raw response: {Response}", responseContent);
            return responseContent;
        }
        catch (TaskCanceledException ex)
        {
            _logger.LogWarning("Request to Azure Foundry timed out: {Message}", ex.Message);
            throw new TimeoutException("The request to Azure Foundry timed out. Please try again.", ex);
        }
        catch (HttpRequestException ex)
        {
            _logger.LogError(ex, "HTTP error communicating with Azure Foundry");
            throw;
        }
        catch (Exception ex)
        {
            _logger.LogError(ex, "Unexpected error in Azure Foundry service");
            throw;
        }
    }

    public async Task<ErrorAnalysisResponse> AnalyzeErrorAsync(
        string code, 
        string errorOutput, 
        CancellationToken cancellationToken = default)
    {
        var prompt = $@"You are a SAS coding expert. Analyze the following SAS code and error output.

SAS Code:
```sas
{code}
```

Error Output:
```
{errorOutput}
```

Please provide:
1. A clear explanation of what the error means
2. The root cause of the error
3. A suggested fix with corrected code

Format your response as JSON with the following structure:
{{
  ""errorExplanation"": ""explanation here"",
  ""rootCause"": ""root cause here"",
  ""suggestedFix"": ""fix description here"",
  ""fixedCode"": ""corrected code here""
}}";

        var response = await SendPromptAsync(prompt, cancellationToken);

        try
        {
            var analysisResponse = JsonSerializer.Deserialize<ErrorAnalysisResponse>(response);
            return analysisResponse ?? new ErrorAnalysisResponse
            {
                ErrorExplanation = response,
                RootCause = "Unable to parse structured response",
                SuggestedFix = "Please review the raw response",
                FixedCode = code
            };
        }
        catch (JsonException)
        {
            // If response is not JSON, return it as plain text
            return new ErrorAnalysisResponse
            {
                ErrorExplanation = response,
                RootCause = "Analysis provided in explanation",
                SuggestedFix = "See explanation for details",
                FixedCode = code
            };
        }
    }

    public async Task<string> AnswerQuestionAsync(
        string question, 
        string? context = null, 
        CancellationToken cancellationToken = default)
    {
        var prompt = string.IsNullOrWhiteSpace(context)
            ? $"You are a SAS programming expert. Answer the following question:\n\n{question}"
            : $"You are a SAS programming expert. Given the conversation context below, answer the question.\n\nContext:\n{context}\n\nQuestion:\n{question}";

        return await SendPromptAsync(prompt, cancellationToken);
    }
}
