using SASCodingAssistant.Models;

namespace SASCodingAssistant.Services;

public interface IAzureFoundryService
{
    Task<string> SendPromptAsync(string prompt, CancellationToken cancellationToken = default);
    Task<ErrorAnalysisResponse> AnalyzeErrorAsync(string code, string errorOutput, CancellationToken cancellationToken = default);
    Task<string> AnswerQuestionAsync(string question, string? context = null, CancellationToken cancellationToken = default);
}
